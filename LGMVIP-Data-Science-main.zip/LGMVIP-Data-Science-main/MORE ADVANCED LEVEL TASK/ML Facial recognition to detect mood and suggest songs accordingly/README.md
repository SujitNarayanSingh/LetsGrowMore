# ML Facial recognition to detect mood and suggest songs accordingly
