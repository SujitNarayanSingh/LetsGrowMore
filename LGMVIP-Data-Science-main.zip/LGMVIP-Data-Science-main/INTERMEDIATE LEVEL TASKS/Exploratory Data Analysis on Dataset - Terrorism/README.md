# As a security/defense analyst, try to find out the hot zone of terrorism.
