# Handwritten equation solver using CNN
Mathematical equation solver using character and symbol recognition using image processing and CNN. 
