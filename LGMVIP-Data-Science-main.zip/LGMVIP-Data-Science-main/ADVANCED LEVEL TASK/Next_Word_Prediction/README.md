Using Tensorflow and Keras library train a RNN, to predict the next word.
